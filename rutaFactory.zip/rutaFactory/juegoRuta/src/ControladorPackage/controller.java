package ControladorPackage;

import ModeloPackage.*;
import VistaPackage.*;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.List;


public class controller {
    private view vista;
    private Scanner scanner;

    public controller() {
        this.scanner = new Scanner(System.in); // Inicializa el Scanner
        this.vista = new view(); // Crea una instancia de Vista
        this.vista.setControlador(this); // Establece este controlador en la vista
    }
    

    public void iniciarJuego() {

        // Obtener el número de jugadores desde la vista
        int numeroJugadores = obtenerNumeroJugadores(); 
        vista.mostrarMenu();
        
        creacionEquipos(numeroJugadores);


    }

    public void creacionEquipos(int numeroJugadores){

        // Lista de jugadores para cada equipo
        List<jugador> jugadoresEquipo1 = new ArrayList<>();
        List<jugador> jugadoresEquipo2 = new ArrayList<>();

        // Agregar jugadores a los equipos según el número obtenido
        for (int i = 0; i < numeroJugadores / 2; i++) {
            jugadoresEquipo1.add(new jugador("Jugador: " + i, null)); // Pasamos null temporalmente como equipo
            jugadoresEquipo2.add(new jugador("Jugador: " + (i + numeroJugadores / 2), null)); // Pasamos null temporalmente como equipo
        }

        // Crear equipos con los nombres y las listas de jugadores correspondientes
        equipo equipo1 = new equipo("Equipo 1", jugadoresEquipo1);
        equipo equipo2 = new equipo("Equipo 2", jugadoresEquipo2);
    }

    public int obtenerNumeroJugadores() {
        System.out.print("Ingrese el número de jugadores: ");
        int val = scanner.nextInt();
        return val;
    }


}

package ModeloPackageInterface;

public interface carta{
    public String getNombre();
    public String getDescripcion();
    public String getRutaImagen();
    public int getCantidadTotalCartas();
}

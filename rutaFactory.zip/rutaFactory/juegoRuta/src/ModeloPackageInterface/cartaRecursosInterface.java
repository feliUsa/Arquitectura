package ModeloPackageInterface;

public interface cartaRecursosInterface {

    public void tipoSolucion(String solucion);

}


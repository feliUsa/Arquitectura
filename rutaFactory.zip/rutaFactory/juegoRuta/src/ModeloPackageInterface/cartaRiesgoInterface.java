package ModeloPackageInterface;

public interface cartaRiesgoInterface {

    public void riesgo(String problema);

}
package VistaPackage;

import java.util.Scanner;
import ControladorPackage.*;

public class view {
   private controller controlador;

    public view() {
        
    }
    
    // Se establece el controlador necesario para la vista
    public void setControlador(controller controlador) {
        this.controlador = controlador;
    }

    public void mostrarMenu() {
        Scanner p = new Scanner(System.in);
        System.out.println("Bienvenido al juego de cartas.");
        System.out.println("1. Iniciar juego");
        System.out.println("2. Salir");
        System.out.print("Seleccione una opción: ");
        int op = p.nextInt(); // Cambiar a nextInt()
        mostrarMensaje(String.valueOf(op));

    }

    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }
}
